package itumulator.simulator;

import itumulator.world.World;
import itumulator.world.Location;
import itumulator.simulator.Bear;
import itumulator.simulator.Rabbit;
import itumulator.simulator.BerryBush;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;


public class BearTest {
    private World w;

    @BeforeEach
    public void setUp() {
        // Lille verden er nok til tests
        w = new World(10);
        w.setDay(); // vi tester dag-adfærd her
    }
    
    @Test
    public void bearGetsTerritoryCenterFromSpawnPosition() {
        Bear b = new Bear();                  // bjørn uden koordinat
        Location start = new Location(3, 3);  // hvor vi placerer den

        w.setTile(start, b);

        // act kaldes – her burde bjørnen sætte sit territoryCenter
        b.act(w);

        assertEquals(start, b.getTerritoryCenter());
    }
    
    
    //TESTER: at findNearbyPrey finder nabo-kaninen
    //at du kalder world.delete(prey)
    //at bjørnen flytter hen på byttets felt
    @Test
    public void bearEatsRabbitAndMovesToItsLocation() {
        World w = new World(10);
        w.setDay();

        Bear b = new Bear(3, 3);
        Rabbit r = new Rabbit();

        Location bearStart   = new Location(3, 3);
        Location rabbitStart = new Location(4, 3);

        w.setTile(bearStart, b);
        w.setTile(rabbitStart, r);

        // Act
        b.act(w);

        // 1) Feltet indeholder nu en bjørn (ikke en kanin)
        Object tile = w.getTile(rabbitStart);
        assertTrue(tile instanceof Bear);

        // 2) Bjørnen står på kaninens gamle felt
        assertEquals(rabbitStart, w.getLocation(b));
    }
    
    //TESTER: at world.getNonBlocking(myPos) finder bush’en
    // at instanceof BerryBush er korrekt
    // at bush.eaten() bliver kaldt
    @Test
    public void bearEatsBerriesFromBush() {
        Bear b = new Bear();
        BerryBush bush = new BerryBush();

        Location pos = new Location(3, 3);

        // Først bush, så bear – i ITUmulator kan der godt stå non-blocking + dyr samme sted
        w.setTile(pos, bush);
        w.setTile(pos, b);

        // Safety: hvis din kode bruger currentLocation til getNonBlocking
        w.setCurrentLocation(pos);

        // Tjek pre-condition: der ER bær
        assertTrue(bush.hasBerries());

        // Bjørnen handler
        b.act(w);

        // Nu burde bær være spist
        assertFalse(bush.hasBerries());
    }
    
    @Test
    public void bearMovesOneStepTowardTerritoryCenterWhenOutside() {
        // Territory center sættes via constructor
        Location center = new Location(3, 3);
        Bear b = new Bear(3, 3);

        // Bjørnen starter UDEN for territoriet (x = 9 > 3+5 = 8)
        Location start = new Location(9, 3);
        w.setTile(start, b);
        w.setCurrentLocation(start); // hvis din kode bruger currentLocation et sted

        // Act: territorie-logikken burde slå til
        b.act(w);

        // Forventet: ét skridt mod center:
        // fra (9,3) → (8,3)
        Location expected = new Location(8, 3);
        Location actual   = w.getLocation(b);

        assertEquals(expected, actual);
    }
}    
    

    
    
