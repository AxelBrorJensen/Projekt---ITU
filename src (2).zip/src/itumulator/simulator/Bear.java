package itumulator.simulator;

import itumulator.simulator.Actor;
import itumulator.world.World;
import itumulator.world.Location;

import java.util.Set;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import itumulator.executable.DynamicDisplayInformationProvider;
import itumulator.executable.DisplayInformation;


public class Bear implements Actor, DynamicDisplayInformationProvider {
    private World myWorld;
    private Location territoryCenter;
    private Random rand = new Random();
    private int energy = 40;
    private int maxEnergy = 40;
    private int age = 0;
    private int maxAge = 80;

    //Bruges når bjørnen oprettes uden koordinat
    public Bear() {
        this.territoryCenter = null;
    }
    
    //Bruges når bjørnen oprettes med koordinat
    public Bear(int x, int y) {
        this.territoryCenter = new Location(x, y);
    }
    
    public Location getTerritoryCenter() {
        return territoryCenter;
    }
    
    @Override
    public void act(World world) {
        this.myWorld = world;
        
        //Sørger for den har et center
        if (territoryCenter == null) {
            territoryCenter = world.getLocation(this);
        }    
        
        // ---- ENERGI TIKKER NED HVER TUR ----
        energy--; 
        if(energy <= 0) {
            // Bjørnen er sultet ihjel
            world.delete(this);
            return;
        }
        
        //--- ALDER --- 
        age++;
        if (age >= maxAge) {
            // Bjørnen dør af alderdom
            world.delete(this);
            return;
        }
        
        Location myPos = world.getLocation(this);
        
         // Bear bevæger sig ikke om natten 
        if (world.isNight()) {
            return;
        }
        
        
        // --- TERRITORIE-LOGIK ---
        int x = myPos.getX();
        int y = myPos.getY();
        int cx = territoryCenter.getX();
        int cy = territoryCenter.getY();

        // Hvis bjørnen er mere end 5 felter væk i x eller y-retning,
        // så er den uden for sit territorie og skal gå hjem
        if (x < cx - 5 || x > cx + 5 || y < cy - 5 || y > cy + 5) {
            moveTowards(territoryCenter, world);
            return; // ingen jagt eller bær uden for territoriet
        }
        
        // --- SPIS BÆR ---
        Object nb = world.getNonBlocking(myPos);
        if (nb instanceof BerryBush) {
            BerryBush bush = (BerryBush) nb; //
            if (bush.hasBerries()) {
                bush.eaten(); // bærrene bliver spist
                
                //Bjørnen får energi af bær
                energy += 2;
                if(energy > maxEnergy) {
                    energy = maxEnergy;
                }
            }
        }
        
        // ---- JAGT ----
        Location preyPos = findNearbyPrey(world, myPos);
        
        if(preyPos != null) {
            
            //Hvis vi står oven på byttet -> spis det
            Object prey = world.getTile(preyPos);
            
            if (prey instanceof Rabbit) {
                energy += 6;
                
            } else if (prey instanceof Wolf) {
                energy += 12;
            }
          
            // Bjørnen spiser byttet
            world.delete(prey);
            
            if (energy > maxEnergy) {
                energy = maxEnergy;
            }
            
            moveTowards(preyPos, world);
            
            return; // meget vigtigt: stop efter jagt
            }
        
        //--- Ellers tilfældig bevægelse ---
        Set<Location> neighbours = world.getEmptySurroundingTiles(myPos);
        if (!neighbours.isEmpty()) {
            List<Location> list = new ArrayList<>(neighbours);
            Location randomLocation = list.get(rand.nextInt(list.size()));
            world.move(this, randomLocation);
        }
        
    }
    
    //Leder efter bytte på nabofelter
    private Location findNearbyPrey(World world, Location myPos) {
        Set<Location> neighbours = world.getSurroundingTiles(myPos);
            
        for (Location l :  neighbours) {
            Object obj = world.getTile(l);
            
            //Bestemmer hvilke dyr en bjørn må spise
            if(obj instanceof Rabbit || obj instanceof Wolf) {
                return l; // fandt bytte → returnér position
            }
            
        }
        return null; // ingen bytte i nærheden
    }
    
    private void moveTowards(Location target, World world) {
        Location myPos = world.getLocation(this);

        // Udregner retningen mod målet i X-retningen:
        int Tx = Integer.compare(target.getX(), myPos.getX());
        
        // Udregn retningen mod målet i Y-retningen:
        int Ty = Integer.compare(target.getY(), myPos.getY());

        // Sammensæt ny position ved at flytte ét felt i retningen (dx, dy)
        Location next = new Location(myPos.getX() + Tx, myPos.getY() + Ty);

        if (world.isTileEmpty(next)) {
            world.move(this, next);
        }
    }
    
    @Override
    public DisplayInformation getInformation() {
        boolean night = (myWorld != null && myWorld.isNight());

        
        if (!night && age <= 20) {
            return new DisplayInformation(java.awt.Color.BLACK, "bear-small");
        }
        if (night && age <= 20) {
                return new DisplayInformation(java.awt.Color.BLACK, "bear-small-sleeping");
        }
        if (!night && age > 20) {
                return new DisplayInformation(java.awt.Color.BLACK, "bear");
        }
        if(night && age > 20) {
               return new DisplayInformation(java.awt.Color.BLACK, "bear-sleeping");             
        }
        // fallback (burde aldrig nås)
        return new DisplayInformation(java.awt.Color.BLACK, "bear");
        }
        }
        



