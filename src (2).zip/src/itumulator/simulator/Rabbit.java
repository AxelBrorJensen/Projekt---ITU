package itumulator.simulator;

import itumulator.simulator.Actor;
import itumulator.world.World;
import itumulator.world.Location;

import java.util.Set;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import itumulator.executable.DynamicDisplayInformationProvider;
import itumulator.executable.DisplayInformation;


public class Rabbit implements Actor, DynamicDisplayInformationProvider {

    private int energy = 20;
    private int maxEnergy = 20;
    private Random rand = new Random();
    private int age = 0;
    
    Burrow myBurrow;
    Location myBurrowLocation;
    boolean isInBurrow = false;

    @Override
    public void act(World world) {

        // Hvis kaninen ER i hul om natten → stop alt
        if (isInBurrow) {

            // Hvis det er dag → prøv at komme op
            if (world.isDay()) {

            // kun hvis der er plads på feltet
            if (world.isTileEmpty(myBurrowLocation)) {
                isInBurrow = false;

            if (myBurrow != null) {
                myBurrow.leave();
                }

                world.setTile(myBurrowLocation, this);
            } else {
            // der står allerede en kanin ovenpå hullet,
            // så vi bliver bare nede denne runde
            }
        }

        return; // meget vigtigt!
        }

        // 2) Hvis det er nat → NAT-AKTIVITET (før ALT andet!)
        if (world.isNight()) {
            handleNight(world);
            return;
        }

        // Alder og energi
        age++;
        energy--;

        //for hver 10 tick falder maxEnergy med 3 (Aldersbetingelse)
        if (age % 10 == 0) {
            maxEnergy = maxEnergy - 3;
        }

        if (energy > maxEnergy) {
            energy = maxEnergy;
        }

        //Dødsbetingelse
        if (maxEnergy <= 0 || energy <= 0) {
            world.delete(this);
            return;
        }

        Location myPos = world.getLocation(this);

        // Spiser græs
        Object nb = world.getNonBlocking(myPos);
        if (nb instanceof Grass) {
            world.remove(nb);
            energy += 5;
        }

        // Reproduktion
        if (age >= 10 && rand.nextDouble() < 0.10) {
            Set<Location> emptyNeighbours = world.getEmptySurroundingTiles(myPos);
            if (!emptyNeighbours.isEmpty()) {
                List<Location> list = new ArrayList<>(emptyNeighbours);
                Location babyLocation = list.get(rand.nextInt(list.size()));
                world.setTile(babyLocation, new Rabbit());
            }
        }

        // Dag-bevægelse
        Set<Location> neighbours = world.getEmptySurroundingTiles(myPos);
        if (!neighbours.isEmpty()) {
            List<Location> list = new ArrayList<>(neighbours);
            Location randomLocation = list.get(rand.nextInt(list.size()));
            world.move(this, randomLocation);
        }

        // Grav hul (kun hvis man ikke har et)
        if (age >= 5 && rand.nextDouble() < 0.3 && energy > 10 && myBurrow == null) {

            myPos = world.getLocation(this);

            if (!world.containsNonBlocking(myPos)) {
                Burrow rabbitsHole = new Burrow();
                world.setTile(myPos, rabbitsHole);

                this.myBurrow = rabbitsHole;
                this.myBurrowLocation = myPos;
            }
        }
    }

    private void handleNight(World world) {

        Location myPos = world.getLocation(this);

        // 1) Hvis kaninen står på et hul → gå ned i det
        Object tileObj = world.getNonBlocking(myPos);
        if (tileObj instanceof Burrow) {
        
            Burrow b = (Burrow) tileObj;
        
            // Kun gå ned hvis der er plads
            if (b.hasSpace()) {
        
                if (myBurrow == null) {
                    myBurrow = b;
                    myBurrowLocation = myPos;
                }
        
                b.enter();          // registrér at en kanin gik ind
                world.remove(this);
                isInBurrow = true;
                return;
            }
        }

        // 2) Hvis kaninen har sit eget hul → gå mod det
        if (myBurrowLocation != null) {
            moveTowards(myBurrowLocation, world);
            return;
        }

        // 3) Hvis kaninen IKKE har eget hul → søg mod nærliggende hul
        Set<Location> neighbours = world.getSurroundingTiles(myPos);

        for (Location l : neighbours) {
            Object o = world.getNonBlocking(l);
            if (o instanceof Burrow) {
                moveTowards(l, world);
                return;
            }
        }

        // 4) Intet hul → gå tilfældigt
        Set<Location> empty = world.getEmptySurroundingTiles(myPos);
        if (!empty.isEmpty()) {
            List<Location> list = new ArrayList<>(empty);
            Location randomLocation = list.get(rand.nextInt(list.size()));
            world.move(this, randomLocation);
        }
    }

    private void moveTowards(Location target, World world) {

        Location myPos = world.getLocation(this);

        int dx = Integer.compare(target.getX(), myPos.getX());
        int dy = Integer.compare(target.getY(), myPos.getY());

        Location next = new Location(myPos.getX() + dx, myPos.getY() + dy);

        if (world.isTileEmpty(next)) {
            world.move(this, next);
        }
    }
    
    public boolean isInBurrow() {
        return isInBurrow;
    }

    @Override
    public DisplayInformation getInformation() {
    if (age <= 10) {
        return new DisplayInformation(java.awt.Color.GRAY, "rabbit-small");
    } else {
        return new DisplayInformation(java.awt.Color.GRAY, "rabbit-large");
    }
    
    }
}