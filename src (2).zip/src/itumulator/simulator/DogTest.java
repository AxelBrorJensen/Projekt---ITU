package itumulator.simulator;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import itumulator.world.World;
import itumulator.world.Location;

import java.util.Set;

public class DogTest {

    @Test
    public void dogFollowsOwner() {
        World w = new World(3);

        Person owner = new Person();
        Dog dog = new Dog(owner);
        owner.setDog(dog);

        
        Location ownerStart = new Location(1,1);
        Location dogStart   = new Location(1,2);

        w.setTile(ownerStart, owner);
        w.setTile(dogStart, dog);

        
        Location ownerNew = new Location(1,0); 
        w.move(owner, ownerNew);

        
        w.setCurrentLocation(ownerNew);
        dog.act(w);

        // Hundens nye placering
        Location dogLoc = w.getLocation(dog);

        // alle naboer omkring ejeren
        Set<Location> neighbours = w.getSurroundingTiles(ownerNew);

        assertTrue(neighbours.contains(dogLoc),
            "Dog should move to one of the tiles surrounding its owner");
    }
}
