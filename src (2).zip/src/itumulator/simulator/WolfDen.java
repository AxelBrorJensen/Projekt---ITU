package itumulator.simulator;
import itumulator.world.NonBlocking;


public class WolfDen implements NonBlocking  {
    // marker-klasse for ulvehule
}