import java.awt.Color;
import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;

import itumulator.simulator.Grass;
import itumulator.executable.DisplayInformation;
import itumulator.executable.Program;
import itumulator.world.Location;
import itumulator.world.World;
import itumulator.simulator.*;


public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        //læser input fil
        String filename1 = "t2-6a.txt";
        Scanner sc = new Scanner(new File(filename1));
        
        int size = sc.nextInt();
        int delay = 1000;
        int displaySize = 800;

        Program p = new Program(size, displaySize, delay);
        World world = p.getWorld();
        Random r = new Random();
        
        // Basis-udseende (DynamicDisplayInformationProvider kan altid override dette)
        p.setDisplayInformation(Grass.class, new DisplayInformation(Color.GREEN, "grass"));
        p.setDisplayInformation(Rabbit.class, new DisplayInformation(Color.GRAY, "rabbit-small"));
        p.setDisplayInformation(Burrow.class, new DisplayInformation(Color.BLACK, "hole-small"));
        p.setDisplayInformation(Bear.class, new DisplayInformation(Color.BLACK, "bear-small"));
        p.setDisplayInformation(Wolf.class, new DisplayInformation(Color.GRAY, "wolf"));
        p.setDisplayInformation(BerryBush.class, new DisplayInformation(Color.MAGENTA, "bush-berries"));
        p.setDisplayInformation(WolfDen.class, new DisplayInformation(Color.BLACK, "hole"));

        
        //alt parsing/placering ligger i InputParser
        InputParser.loadFile(sc, world, r);


        p.show();
        p.run();
    }
    }
