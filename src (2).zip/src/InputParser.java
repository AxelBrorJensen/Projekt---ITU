
import java.util.Scanner;
import java.util.Random;
import itumulator.world.World;
import itumulator.world.Location;
import itumulator.simulator.Grass;
import itumulator.simulator.Rabbit;
import itumulator.simulator.Burrow;
import itumulator.simulator.Bear;
import itumulator.simulator.BerryBush;
import itumulator.simulator.Wolf;

public class InputParser {

    public static void loadFile(Scanner sc, World world, Random rand) {
        while (sc.hasNext()) {
            String type = sc.next().toLowerCase();
            String amountStr = sc.next();            // læser "3" eller "20-30"
            int amount = parseAmount(amountStr, rand);
            
            // ---- NYT: TJEK FOR KOORDINATER ----
            // Antag der ikke er et koordinat
            boolean hasCoordinat = false;
            
            // Hvis koordinater IKKE findes, bruger vi -1.
            // (-1 fordi koordinater ALDRIG er negative i vores verden)
            int coordinatX = -1;
            int coordinatY = -1;
            
            // Vi læser RESTEN af linjen efter type og amount.
            // Eksempel: "Bear 1 (3,5)" → restOfLine = "(3,5)"
            String restOfLine = "";
            if (sc.hasNextLine()) {
                restOfLine = sc.nextLine().trim();
            }
            // Tjekker om der står noget på resten af linjen…
            if (!restOfLine.isEmpty()) {

                // Tjekker om resten ligner et koordinat i formen: (x,y)
                if (restOfLine.startsWith("(") && restOfLine.endsWith(")") && restOfLine.contains(",")) {
                    // Fjern parenteser: "(3,5)" → "3,5"
                    String coordinatText = restOfLine.substring(1, restOfLine.length() - 1);
                    // Split i to ved komma
                    String[] parts = coordinatText.split(",");
                    // Konverter begge dele fra tekst til tal
                    // trim() fjerner evt. mellemrum: " 3 " → "3"
                    coordinatX = Integer.parseInt(parts[0].trim());
                    coordinatY = Integer.parseInt(parts[1].trim());
            
                    hasCoordinat = true;
                }
            }

            //Håndtere type
            if (type.equals("grass")) {
                plantRandomGrass(world, amount, rand);
                
            } else if (type.equals("rabbit")) {
                plantRandomRabbits(world, amount, rand);
                
            } else if (type.equals("burrow")) {
                plantRandomBurrows(world, amount, rand);
                
            } else if (type.equals("wolf")) {
                plantRandomWolfs(world, amount, rand);
                
            } else if (type.equals("bear")) {
                if (hasCoordinat) {
                    // Bear med startkoordinat
                    plantBearAt(world, amount, coordinatX, coordinatY);
                } else {
                    // Bear uden koordinat = tilfældig
                    plantRandomBears(world, amount, rand);
                }
            } else if (type.equals("berry")) {
                plantRandomBerries(world, amount, rand);

            }
        }
    }

    // hjælpe metode til at plante random grass i verdenen
    private static void plantRandomGrass(World world, int amount, Random rand) {
        int size = world.getSize();
    
        for (int i = 0; i < amount; i++) {
            Location l;
            do {
                l = new Location(rand.nextInt(size), rand.nextInt(size));
            } while (world.getTile(l) != null || world.containsNonBlocking(l));
            world.setTile(l, new Grass());
        }
    }
    
    // hjælpe metode til at plante random kaniner i verdenen
    private static void plantRandomRabbits(World world, int amount, Random rand) {
        int size = world.getSize();

        for (int i = 0; i < amount; i++) {
            Location l;
            do {
                l = new Location(rand.nextInt(size), rand.nextInt(size));
            } while (world.getTile(l) != null);
            world.setTile(l, new Rabbit());
        }
    }
    
    // hjælpe metode til at plante random Burrows i verdenen
    private static void plantRandomBurrows(World world, int amount, Random rand) {
        int size = world.getSize();
        
        for (int i = 0; i < amount; i++) {
            Location l;
            do {
                l = new Location(rand.nextInt(size), rand.nextInt(size));
            } while (world.getTile(l) != null);
            world.setTile(l, new Burrow());
        }
    }
    
    // hjælpe metode til at plante random Wolfs i verdenen
    private static void plantRandomWolfs(World world, int amount, Random rand) {
        int size = world.getSize();

        for (int i = 0; i < amount; i++) {
            Location l;
            do {
                l = new Location(rand.nextInt(size), rand.nextInt(size));
            } while (world.getTile(l) != null);
            world.setTile(l, new Wolf());
        }
    }
    
    // hjælpe metode til at plante random Bears i verdenen
    private static void plantRandomBears(World world, int amount, Random rand) {
        int size = world.getSize();
        
        for (int i = 0; i < amount; i++) {
            Location l;
            do {
                l = new Location(rand.nextInt(size), rand.nextInt(size));
            } while (world.getTile(l) != null);
            
            Bear b = new Bear(); // ← uden koordinater
            world.setTile(l, b);
        }
    }
    
    // hjælpe metode til at plante bear på bestemt startkordinat i verdenen
    private static void plantBearAt(World world, int amount, int x, int y) {
        int size = world.getSize();
        for (int i = 0; i < amount; i++) {
            Location l = new Location(x, y);
            if(world.isTileEmpty(l)) {
                Bear b = new Bear(x, y); // ← med koordinater
                world.setTile(l, b);
            }
        }
    }
    
    // hjælpe metode til at plante random "berries" i verdenen
    private static void plantRandomBerries(World world, int amount, Random rand) {
        int size = world.getSize();
    
        for (int i = 0; i < amount; i++) {
            Location l;
            do {
                l = new Location(rand.nextInt(size), rand.nextInt(size));
            } while (world.getTile(l) != null || world.containsNonBlocking(l));
            world.setTile(l, new BerryBush());
        }
    }
    
    // Metode til at tolke "3" / "20-30"
    private static int parseAmount(String amountStr, Random rand) {
        
        // Hvis det er et interval: fx "20-30"
        if (amountStr.contains("-")) {
            String[] parts = amountStr.split("-");
            int min = Integer.parseInt(parts[0]);
            int max = Integer.parseInt(parts[1]);
            return min + rand.nextInt(max - min + 1);
        } else {
            // Hvis det er et enkelt tal: fx "3"
            return Integer.parseInt(amountStr);
        }
    }
}