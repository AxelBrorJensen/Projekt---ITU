import java.awt.Color;
import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;

import itumulator.simulator.Grass;
import itumulator.executable.DisplayInformation;
import itumulator.executable.Program;
import itumulator.world.Location;
import itumulator.world.World;
import itumulator.simulator.Person;
import itumulator.simulator.Dog;
import itumulator.simulator.Rabbit;
import itumulator.simulator.Burrow;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        //læser input fil
        String filename1 = "t1-2cde.txt";
        Scanner sc = new Scanner(new File(filename1));
        
        int size = sc.nextInt();
        int delay = 1000;
        int displaySize = 800;

        Program p = new Program(size, displaySize, delay);
        World world = p.getWorld();
        Random r = new Random();
        
        p.setDisplayInformation(Grass.class, new DisplayInformation(Color.GREEN, "grass"));
        p.setDisplayInformation(Rabbit.class, new DisplayInformation(Color.GRAY, "rabbit-small"));
        p.setDisplayInformation(Burrow.class, new DisplayInformation(Color.BLACK, "hole-small"));
    
        //alt parsing/placering ligger i InputParser
        InputParser.loadFile(sc, world, r);


        p.show();
        p.run();
    }
    }
