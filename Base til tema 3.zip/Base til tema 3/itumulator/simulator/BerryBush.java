package itumulator.simulator;

import itumulator.simulator.*;
import itumulator.world.*;
import itumulator.world.NonBlocking;
import itumulator.world.Location;
import itumulator.executable.DynamicDisplayInformationProvider;
import itumulator.executable.DisplayInformation;


public class BerryBush implements Actor, NonBlocking, DynamicDisplayInformationProvider {
    private boolean hasBerries = true;  // starter med bær på busken
    private int growTimer = 0;
    private static final int GROW_TIME = 10; // hvor mange ticks før bærrene er tilbage

    
    @Override
    public void act(World world) {
        // hvis busken ingen bær har, tæller vi ned til de gror igen
        if (!hasBerries) {
            growTimer++;
            if (growTimer >= GROW_TIME) {
                hasBerries = true;
                growTimer = 0;
            }
        }
    }
    
    public boolean hasBerries() {
        return hasBerries;
    }
    
    // kaldes når en bjørn spiser bærrene
    public void eaten() {
        hasBerries = false;
        growTimer = 0;
    }
    
    @Override
    public DisplayInformation getInformation() {
        if(hasBerries) {
            //Busk med bær vises
            return new DisplayInformation(java.awt.Color.GREEN, "bush-berries");
        } else {
            //Busk uden bær vises
            return new DisplayInformation(java.awt.Color.GREEN, "bush");
        }
    } 
}  