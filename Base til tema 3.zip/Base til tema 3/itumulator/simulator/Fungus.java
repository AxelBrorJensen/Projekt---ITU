package itumulator.simulator;

import itumulator.simulator.Actor;
import itumulator.world.World;
import itumulator.world.Location;
import java.awt.Color;

import itumulator.executable.DynamicDisplayInformationProvider;
import itumulator.executable.DisplayInformation;

import java.util.Set;

public class Fungus implements Actor, DynamicDisplayInformationProvider {

    private int lifetime;
    private boolean visible = false;

    public Fungus(int strength) {
        this.lifetime = 5 + strength; // længere hvis større ådsel
    }

    public void tickInsideCarcass() {
        // Ingen handling før den er synlig
    }

    public void setVisible(boolean v) {
        this.visible = v;
    }

    @Override
    public void act(World world) {
        if (!visible) return;

        Location myPos = world.getLocation(this);
        if (myPos == null) return;

        // Se radius 2 efter ådsler
        boolean foundCarcass = false;
        Set<Location> area = world.getSurroundingTiles(myPos);

        for (Location l : area) {
            Object o = world.getTile(l);
            if (o instanceof Carcass) {
                foundCarcass = true;
                break;
            }
        }

        if (!foundCarcass) {
            lifetime--;
            if (lifetime <= 0) {
                world.delete(this);
            }
        }
    }

    @Override
    public DisplayInformation getInformation() {
        return new DisplayInformation(Color.MAGENTA, "fungus");
    }
}
