package itumulator.simulator;

import itumulator.world.World;
import itumulator.world.Location;

public abstract class Herbivore extends Animal {

    public Herbivore(int energy, int maxEnergy, int maxAge) {
        super(energy, maxEnergy, maxAge);
    }

    @Override
    protected void animalAct(World world) {
        // Som udgangspunkt gør planteædere meget lidt
        // Rabbit overrides dette fuldstændigt.
        moveRandom(world);
    }
}