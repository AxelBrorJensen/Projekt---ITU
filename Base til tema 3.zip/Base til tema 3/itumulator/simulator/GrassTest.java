package itumulator.simulator;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;

import itumulator.world.World;
import itumulator.world.Location;

import java.util.Set; 

public class GrassTest {
    private World w;
    
    @Test
    public void grassCanSpread() {
        w = new World(3);
        Location l = new Location(1, 1);
        Grass g = new Grass();
        w.setTile(l, g);

        // giver grass mange forsøg til at sprede sig
        for (int i = 0; i < 200; i++) {
        g.act(w);
        }
    
        boolean Spread = false;
        
        for (Location n : w.getSurroundingTiles(l)) {
            if(w.getTile(n) instanceof Grass) {
                Spread = true;   // vi markerer at der er spredt
            }
        }
        assertTrue(Spread, "Grass burde have spredt sig til en nabo.");
    }
}
