package itumulator.simulator;

import itumulator.world.World;
import itumulator.world.Location;
import itumulator.executable.DisplayInformation;

import java.awt.Color;

public class Bear extends Carnivore {

    private Location territoryCenter;
    private boolean isNightCached = false;

    // Normal konstruktor
    public Bear() {
        super(40, 40, 80, 6);
    }

    // Bruges i tests
    public Bear(int x, int y) {
        super(40, 40, 80, 6);
        this.territoryCenter = new Location(x, y);
    }

    public Location getTerritoryCenter() {
        return territoryCenter;
    }

    @Override
    protected void animalAct(World world) {
        isNightCached = world.isNight();

        // Sæt territorie første gang
        if (territoryCenter == null) {
            territoryCenter = world.getLocation(this);
        }

        // Bevæg dig hjem hvis udenfor territoriet
        Location pos = world.getLocation(this);
        int cx = territoryCenter.getX();
        int cy = territoryCenter.getY();

        if (Math.abs(pos.getX() - cx) > 5 || Math.abs(pos.getY() - cy) > 5) {
            moveTowards(world, territoryCenter);
            return;
        }

        // Resten styres af Carnivore
        super.animalAct(world);
    }

    @Override
    protected boolean isPrey(Object obj) {
        return obj instanceof Rabbit || obj instanceof Wolf;
    }

    @Override
    protected int getMeatValueFromPrey(Object prey) {
        if (prey instanceof Rabbit) return 5;
        if (prey instanceof Wolf) return 15;
        return 10;
    }

    @Override
    protected int getMeatValue() {
        return 30;
    }

    // (valgfrit – kun hvis du bruger DynamicDisplay)
    public DisplayInformation getInformation() {
        boolean small = age <= 20;

        if (!isNightCached && small)
            return new DisplayInformation(Color.BLACK, "bear-small");

        if (isNightCached && small)
            return new DisplayInformation(Color.BLACK, "bear-small-sleeping");

        if (!isNightCached)
            return new DisplayInformation(Color.BLACK, "bear");

        return new DisplayInformation(Color.BLACK, "bear-sleeping");
    }
}
