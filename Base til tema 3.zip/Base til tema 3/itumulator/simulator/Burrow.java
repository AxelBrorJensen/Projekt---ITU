package itumulator.simulator;

import itumulator.world.World;
import itumulator.simulator.Actor;
import java.util.Random;
import itumulator.world.NonBlocking;

public class Burrow implements  NonBlocking {
    
    private int rabbitsInside = 0;
    private static final int MAX_CAPACITY = 5;

    public boolean hasSpace() {
        return rabbitsInside < MAX_CAPACITY;
    }

    public void enter() {
        rabbitsInside++;
    }

    public void leave() {
        rabbitsInside--;
    }
    
}