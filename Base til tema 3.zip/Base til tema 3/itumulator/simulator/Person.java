package itumulator.simulator;

import itumulator.simulator.Actor;
import itumulator.world.World;
import itumulator.world.Location;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.Random;

public class Person implements Actor {

    private Random random = new Random();
    private Dog dog;

    @Override
    public void act(World world) {

 
        if (world.isNight()) {
            world.delete(this);
            return;
        }

 
        Location myPos = world.getLocation(this);

      
        if (dog == null) {
            double chance = 0.20;

            if (random.nextDouble() < chance) {

         
                Set<Location> empty = world.getEmptySurroundingTiles(myPos);

                if (!empty.isEmpty()) {
                    List<Location> list = new ArrayList<>(empty);
                    Location dogLocation = list.get(random.nextInt(list.size()));

                    Dog d = new Dog(this);
                    this.dog = d;

                    world.setTile(dogLocation, d);
                }
            }
        }

 
        myPos = world.getLocation(this);
        Set<Location> neighbours = world.getEmptySurroundingTiles(myPos);

        if (!neighbours.isEmpty()) {
            List<Location> list = new ArrayList<>(neighbours);
            Location randomLocation = list.get(random.nextInt(list.size()));
            world.move(this, randomLocation);
        }
    }

    public Dog getDog() {
        return dog;
    }

    public void setDog(Dog dog) {
        this.dog = dog;
    }
}
