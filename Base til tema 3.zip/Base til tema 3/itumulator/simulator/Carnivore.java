package itumulator.simulator;

import itumulator.world.World;
import itumulator.world.Location;

import java.util.Set;

public abstract class Carnivore extends Animal {

    protected int eatPower;

    public Carnivore(int energy, int maxEnergy, int maxAge, int eatPower) {
        super(energy, maxEnergy, maxAge);
        this.eatPower = eatPower;
    }

    @Override
    protected void animalAct(World world) {
        // Spis ådsel hvis vi står ovenpå det
        if (tryEatCarcass(world)) return;

        // Forsøg at jage levende dyr
        if (tryHunt(world)) return;

        // Ellers bevæg dig tilfældigt
        moveRandom(world);
    }

    protected boolean tryEatCarcass(World world) {
        Object tile = world.getTile(world.getLocation(this));

        if (tile instanceof Carcass carcass) {
            carcass.eatMeat(eatPower);
            energy = Math.min(maxEnergy, energy + eatPower);
            return true;
        }
        return false;
    }

    protected boolean tryHunt(World world) {
        Location pos = world.getLocation(this);
        Set<Location> surroundings = world.getSurroundingTiles(pos);

        for (Location l : surroundings) {
            Object obj = world.getTile(l);

            if (obj != null && isPrey(obj)) {

                // --- Dræb byttet og lav ådsel ---
                int meat = getMeatValueFromPrey(obj);
                Carcass c = new Carcass(meat);
                world.delete(obj);
                world.setTile(l, c);

                // Flyt rovdyret ind på ådslet
                if (world.isTileEmpty(l)) {
                    world.move(this, l);
                }

                // Spis af ådslet
                c.eatMeat(eatPower);
                energy = Math.min(maxEnergy, energy + eatPower);

                return true;
            }
        }

        return false;
    }

    protected abstract boolean isPrey(Object obj);
    protected abstract int getMeatValueFromPrey(Object prey);
}
