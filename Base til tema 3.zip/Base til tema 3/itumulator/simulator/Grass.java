package itumulator.simulator;
import itumulator.world.World;
import itumulator.simulator.Actor;
import itumulator.world.Location;
import java.util.Scanner;
import java.io.File;
import java.util.Random;
import java.util.Set;
import java.util.List;
import java.util.ArrayList;
import itumulator.world.NonBlocking;

public class Grass implements Actor, NonBlocking {    
    
    private Random rand = new Random();

    @Override
    public void act(World world) {
        
        if (!world.contains(this)) {
            return;
        }
        
        //chance for spredning
        double spreadChance = 0.001;
        
        if (rand.nextDouble() >= spreadChance) {
            return;
        }
        
        // Find min egen placering
        Location myPos;
        try {
            myPos = world.getLocation(this);

        } catch (IllegalArgumentException e) {
            return;
        }

        // Find ALLE naboer
        Set<Location> neighbours = world.getSurroundingTiles(myPos);
        
        // Lav en liste med FELTER som er HELT tomme
        List<Location> empty = new ArrayList<>();
        for (Location loc : neighbours) {
            
        // Felt er kun tomt hvis:
        // - world.getTile(loc) == null  → ingen blocking objekt
        // - !world.containsNonBlocking(loc)  → ingen grass   
        if(world.getTile(loc) == null && !world.containsNonBlocking(loc)) {
            empty.add(loc);
            }
        }

        
         if (empty.isEmpty()) {
            return;
        }
        
        Location grassSpot = empty.get(rand.nextInt(empty.size()));
        
        world.setTile(grassSpot, new Grass());

    }
}

