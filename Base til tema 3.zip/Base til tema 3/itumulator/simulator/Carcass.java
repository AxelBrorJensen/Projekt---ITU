package itumulator.simulator;

import itumulator.simulator.Actor;
import itumulator.world.World;
import itumulator.world.Location;
import itumulator.executable.DynamicDisplayInformationProvider;
import itumulator.executable.DisplayInformation;

import java.awt.Color;
import java.util.Set;

public class Carcass implements Actor, DynamicDisplayInformationProvider {

    private int meat;           // hvor meget kød der er tilbage (bruges af dyr)
    private int rotTimer = 0;   // hvor råddent ådslet er
    private final int ROT_LIMIT = 25;

    private Fungus fungus;      // svamp inde i ådslet (kan være null)
    private boolean fungusVisible = false;  // bruges når svamp bliver synlig efter ådsel er væk

    private boolean hasFungus;  


    // Uden svamp
    public Carcass(int meat) {
        this.meat = meat;
        this.hasFungus = false;
    }

    // Med svamp (fra input)
    public Carcass(int meat, int fungusStrength) {
        this.meat = meat;
        this.fungus = new Fungus(fungusStrength);
        this.hasFungus = true;
    }

    public boolean hasFungus() {
        return fungus != null;
    }

    public int eatMeat(int amount) {
        int eaten = Math.min(amount, meat);
        meat -= eaten;
        return eaten;
    }

    @Override
    public void act(World world) {

        Location myPos = world.getLocation(this);
        if (myPos == null) return;

        rotTimer++;

        // Svamp nedbryder hurtigere
        if (fungus != null && !fungusVisible) {
            fungus.tickInsideCarcass();
            meat--;  
        }

        // Hvis alt kød er væk eller ådslet er for råddent
        if (meat <= 0 || rotTimer >= ROT_LIMIT) {

            // Ådslet forsvinder...
            world.delete(this);

            // Hvis der var en svamp inde i ådslet → gør den synlig!
            if (fungus != null) {
                fungusVisible = true;
                fungus.setVisible(true);
                world.setTile(myPos, fungus);
            }

            return;
        }
    }

    @Override
    public DisplayInformation getInformation() {

        // Hvis svampen er synlig → vis den i stedet
        if (fungusVisible && fungus != null) {
            return fungus.getInformation();
        }

        // Ådslet bliver mere brunt med tiden
        int rotLevel = Math.min(rotTimer * 10, 200);
        Color c = new Color(150 + rotLevel/4, 100 + rotLevel/6, 50);

        if (hasFungus) {
            return new DisplayInformation(c, "carcass-fungi");
        } else {
            return new DisplayInformation(c, "carcass");
        }
    }

}
