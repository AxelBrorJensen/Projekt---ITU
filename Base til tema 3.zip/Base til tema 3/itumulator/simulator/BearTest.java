package itumulator.simulator;

import itumulator.world.*;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

public class BearTest {
    private World w;

    @BeforeEach
    public void setUp() {
        w = new World(10);
        w.setDay();
    }

    @Test
    public void bearGetsTerritoryCenterFromSpawnPosition() {
        Bear b = new Bear();
        Location start = new Location(3, 3);

        w.setTile(start, b);
        w.setCurrentLocation(start);

        b.act(w);

        assertEquals(start, b.getTerritoryCenter());
    }

    @Test
    public void bearEatsRabbitAndMovesToItsLocation() {
        Bear b = new Bear(3, 3);
        Rabbit r = new Rabbit();

        Location bearStart   = new Location(3, 3);
        Location rabbitStart = new Location(4, 3);

        w.setTile(bearStart, b);
        w.setTile(rabbitStart, r);

        w.setCurrentLocation(bearStart);
        b.act(w);

        Object tile = w.getTile(rabbitStart);
        assertTrue(tile instanceof Carcass || tile instanceof Bear);
    }

    @Test
    public void bearEatsBerriesFromBush() {
        Bear b = new Bear();
        BerryBush bush = new BerryBush();

        Location pos = new Location(3, 3);
        w.setTile(pos, b);
        w.setCurrentLocation(pos, bush);

        w.setCurrentLocation(pos);
        assertTrue(bush.hasBerries());

        b.act(w);

        assertFalse(bush.hasBerries());
    }

    @Test
    public void bearMovesOneStepTowardTerritoryCenterWhenOutside() {
        Bear b = new Bear(3, 3);

        Location start = new Location(9, 3);
        w.setTile(start, b);
        w.setCurrentLocation(start);

        b.act(w);

        Location expected = new Location(8, 3);
        assertEquals(expected, w.getLocation(b));
    }
}
