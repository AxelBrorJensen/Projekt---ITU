package itumulator.simulator;

import itumulator.simulator.Actor;
import itumulator.world.World;
import itumulator.world.Location;

import java.util.*;

public abstract class Animal implements Actor {

    protected int energy;
    protected int maxEnergy;
    protected int age = 0;
    protected int maxAge;
    protected Random rand = new Random();

    public Animal(int energy, int maxEnergy, int maxAge) {
        this.energy = energy;
        this.maxEnergy = maxEnergy;
        this.maxAge = maxAge;
    }

    @Override
    public final void act(World world) {

        Location pos = world.getLocation(this);
        if (pos == null) return;

        //Livscyklus
        energy--;
        age++;

        if (energy <= 0 || age >= maxAge) {
            die(world);
            return;
        }

        // opførsel i subklasser 
        animalAct(world);
    }

    protected abstract void animalAct(World world);

    // Flyttefunktioner 
    protected void moveRandom(World world) {
        Location pos = world.getLocation(this);
        Set<Location> free = world.getEmptySurroundingTiles(pos);
        if (free.isEmpty()) return;

        List<Location> list = new ArrayList<>(free);
        Location next = list.get(rand.nextInt(list.size()));
        world.move(this, next);
    }

    protected void moveTowards(World world, Location target) {
        Location pos = world.getLocation(this);
        if (pos == null) return;

        int dx = Integer.compare(target.getX(), pos.getX());
        int dy = Integer.compare(target.getY(), pos.getY());

        Location next = new Location(pos.getX() + dx, pos.getY() + dy);

        if (world.isTileEmpty(next)) {
            world.move(this, next);
        }
    }

    // Død og opret ådsel (Carcass) 
    protected void die(World world) {
        Location pos = world.getLocation(this);
        world.delete(this);

        Carcass carcass = new Carcass(getMeatValue());
        world.setTile(pos, carcass);
    }

    protected abstract int getMeatValue();
}
