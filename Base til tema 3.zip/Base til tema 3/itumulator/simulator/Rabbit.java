package itumulator.simulator;

import itumulator.simulator.Actor;
import itumulator.world.*;

import java.util.*;

import itumulator.executable.*;


import java.awt.Color;
import java.util.*;

public class Rabbit extends Herbivore implements DynamicDisplayInformationProvider {

    Burrow myBurrow;
    Location myBurrowLocation;
    boolean isInBurrow = false;

    public Rabbit() {
        super(20, 20, 60); // energy, maxEnergy, maxAge
    }

    @Override
    protected void animalAct(World world) {

        // 0) Hvis i hul om natten → prøv at komme op
        if (isInBurrow) {
            if (world.isDay()) {
                tryLeaveBurrow(world);
            }
            return;
        }

        // 1) NAT-LOGIK KOMMER FØR ALT
        if (world.isNight()) {
            handleNight(world);
            return;
        }

        // 2) DAG – Først aging-regler
        age++;
        energy--;

        // maxEnergy falder hver 10. tick
        if (age % 10 == 0) {
            maxEnergy -= 3;
            if (maxEnergy < 1) maxEnergy = 1;
        }

        if (energy > maxEnergy)
            energy = maxEnergy;

        // dødsregel — Animal.super.die() håndterer nu carcass
        if (energy <= 0 || maxEnergy <= 0) {
            die(world);
            return;
        }

        Location myPos = world.getLocation(this);

        // 3) Spis græs (Herbivore gør det allerede, men vi vil give +5)
        Object nb = world.getNonBlocking(myPos);
        if (nb instanceof Grass) {
            world.remove(nb);
            energy = Math.min(maxEnergy, energy + 5);
        }

        // 4) Reproduktion
        if (age >= 10 && rand.nextDouble() < 0.10) {
            Set<Location> empty = world.getEmptySurroundingTiles(myPos);
            if (!empty.isEmpty()) {
                List<Location> list = new ArrayList<>(empty);
                Location babySpot = list.get(rand.nextInt(list.size()));
                world.setTile(babySpot, new Rabbit());
            }
        }

        // 5) Bevægelse
        moveRandom(world);

        // 6) Grav hul
        maybeDigBurrow(world);
    }

    private void tryLeaveBurrow(World world) {
        if (world.isTileEmpty(myBurrowLocation)) {

            isInBurrow = false;
            if (myBurrow != null) {
                myBurrow.leave();
            }

            world.setTile(myBurrowLocation, this);
        }
    }

    private void maybeDigBurrow(World world) {
        if (age >= 5 && energy > 10 && myBurrow == null && rand.nextDouble() < 0.30) {
            Location pos = world.getLocation(this);

            if (!world.containsNonBlocking(pos)) {
                Burrow newHole = new Burrow();
                world.setTile(pos, newHole);

                this.myBurrow = newHole;
                this.myBurrowLocation = pos;
            }
        }
    }

    private void handleNight(World world) {

        Location pos = world.getLocation(this);

        // 1) Står ovenpå et hul → gå ned i det
        Object o = world.getNonBlocking(pos);
        if (o instanceof Burrow b && b.hasSpace()) {

            if (myBurrow == null) {
                myBurrow = b;
                myBurrowLocation = pos;
            }

            b.enter();
            world.remove(this);
            isInBurrow = true;
            return;
        }

        // 2) Har eget hul → gå mod det
        if (myBurrowLocation != null) {
            moveTowards(world, myBurrowLocation);
            return;
        }

        // 3) Find andre huller → gå mod det
        for (Location l : world.getSurroundingTiles(pos)) {
            Object nb = world.getNonBlocking(l);
            if (nb instanceof Burrow) {
                moveTowards(world, l);
                return;
            }
        }

        // 4) Intet hul → tilfældig bevægelse
        moveRandom(world);
    }

    public boolean isInBurrow() {
        return isInBurrow;
    }

    @Override
    protected int getMeatValue() {
        return 5;
    }

    @Override
    public DisplayInformation getInformation() {
        if (age <= 10)
            return new DisplayInformation(Color.GRAY, "rabbit-small");
        return new DisplayInformation(Color.GRAY, "rabbit-large");
    }
}



/*public class Rabbit implements Actor, DynamicDisplayInformationProvider {

    private int energy = 20;
    private int maxEnergy = 20;
    private Random rand = new Random();
    private int age = 0;
    
    Burrow myBurrow;
    Location myBurrowLocation;
    boolean isInBurrow = false;

    @Override
    public void act(World world) {

        // Hvis kaninen ER i hul om natten → stop alt
        if (isInBurrow) {

            // Hvis det er dag → prøv at komme op
            if (world.isDay()) {

            // kun hvis der er plads på feltet
            if (world.isTileEmpty(myBurrowLocation)) {
                isInBurrow = false;

            if (myBurrow != null) {
                myBurrow.leave();
                }

                world.setTile(myBurrowLocation, this);
            } else {
            // der står allerede en kanin ovenpå hullet,
            // så vi bliver bare nede denne runde
            }
        }

        return; // meget vigtigt!
        }

        // 2) Hvis det er nat → NAT-AKTIVITET (før ALT andet!)
        if (world.isNight()) {
            handleNight(world);
            return;
        }

        // Alder og energi
        age++;
        energy--;

        //for hver 10 tick falder maxEnergy med 3 (Aldersbetingelse)
        if (age % 10 == 0) {
            maxEnergy = maxEnergy - 3;
        }

        if (energy > maxEnergy) {
            energy = maxEnergy;
        }

        //Dødsbetingelse
        if (maxEnergy <= 0 || energy <= 0) {
            world.delete(this);
            return;
        }

        Location myPos = world.getLocation(this);

        // Spiser græs
        Object nb = world.getNonBlocking(myPos);
        if (nb instanceof Grass) {
            world.remove(nb);
            energy += 5;
        }

        // Reproduktion
        if (age >= 10 && rand.nextDouble() < 0.10) {
            Set<Location> emptyNeighbours = world.getEmptySurroundingTiles(myPos);
            if (!emptyNeighbours.isEmpty()) {
                List<Location> list = new ArrayList<>(emptyNeighbours);
                Location babyLocation = list.get(rand.nextInt(list.size()));
                world.setTile(babyLocation, new Rabbit());
            }
        }

        // Dag-bevægelse
        Set<Location> neighbours = world.getEmptySurroundingTiles(myPos);
        if (!neighbours.isEmpty()) {
            List<Location> list = new ArrayList<>(neighbours);
            Location randomLocation = list.get(rand.nextInt(list.size()));
            world.move(this, randomLocation);
        }

        // Grav hul (kun hvis man ikke har et)
        if (age >= 5 && rand.nextDouble() < 0.3 && energy > 10 && myBurrow == null) {

            myPos = world.getLocation(this);

            if (!world.containsNonBlocking(myPos)) {
                Burrow rabbitsHole = new Burrow();
                world.setTile(myPos, rabbitsHole);

                this.myBurrow = rabbitsHole;
                this.myBurrowLocation = myPos;
            }
        }
    }

    private void handleNight(World world) {

        Location myPos = world.getLocation(this);

        // 1) Hvis kaninen står på et hul → gå ned i det
        Object tileObj = world.getNonBlocking(myPos);
        if (tileObj instanceof Burrow) {
        
            Burrow b = (Burrow) tileObj;
        
            // Kun gå ned hvis der er plads
            if (b.hasSpace()) {
        
                if (myBurrow == null) {
                    myBurrow = b;
                    myBurrowLocation = myPos;
                }
        
                b.enter();          // registrér at en kanin gik ind
                world.remove(this);
                isInBurrow = true;
                return;
            }
        }

        // 2) Hvis kaninen har sit eget hul → gå mod det
        if (myBurrowLocation != null) {
            moveTowards(myBurrowLocation, world);
            return;
        }

        // 3) Hvis kaninen IKKE har eget hul → søg mod nærliggende hul
        Set<Location> neighbours = world.getSurroundingTiles(myPos);

        for (Location l : neighbours) {
            Object o = world.getNonBlocking(l);
            if (o instanceof Burrow) {
                moveTowards(l, world);
                return;
            }
        }

        // 4) Intet hul → gå tilfældigt
        Set<Location> empty = world.getEmptySurroundingTiles(myPos);
        if (!empty.isEmpty()) {
            List<Location> list = new ArrayList<>(empty);
            Location randomLocation = list.get(rand.nextInt(list.size()));
            world.move(this, randomLocation);
        }
    }

    private void moveTowards(Location target, World world) {

        Location myPos = world.getLocation(this);

        int dx = Integer.compare(target.getX(), myPos.getX());
        int dy = Integer.compare(target.getY(), myPos.getY());

        Location next = new Location(myPos.getX() + dx, myPos.getY() + dy);

        if (world.isTileEmpty(next)) {
            world.move(this, next);
        }
    }
    
    public boolean isInBurrow() {
        return isInBurrow;
    }

    @Override
    public DisplayInformation getInformation() {
    if (age <= 10) {
        return new DisplayInformation(java.awt.Color.GRAY, "rabbit-small");
    } else {
        return new DisplayInformation(java.awt.Color.GRAY, "rabbit-large");
    }
    
    }
}*/