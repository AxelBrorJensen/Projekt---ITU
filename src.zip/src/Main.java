import java.awt.Color;
import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;

import itumulator.simulator.Grass;
import itumulator.executable.DisplayInformation;
import itumulator.executable.Program;
import itumulator.world.Location;
import itumulator.world.World;
import itumulator.simulator.Person;
import itumulator.simulator.Dog;
import itumulator.simulator.Rabbit;
import itumulator.simulator.Burrow;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        //læser input fil grass
        String filename1 = "t1-3b.txt";
        Scanner sc = new Scanner(new File(filename1));
        
        int size = sc.nextInt();
        int delay = 1000;
        int displaySize = 800;

        Program p = new Program(size, displaySize, delay);
        World world = p.getWorld();
        Random r = new Random();
        
        p.setDisplayInformation(Grass.class, new DisplayInformation(Color.GREEN, "grass"));
        p.setDisplayInformation(Rabbit.class, new DisplayInformation(Color.GRAY, "rabbit-small"));
        p.setDisplayInformation(Burrow.class, new DisplayInformation(Color.BLACK, "hole-small"));
    
        
        while (sc.hasNext()) {
            String type = sc.next();
            String amountStr = sc.next();            // læser "3" eller "20-30"
            int amount = parseAmount(amountStr, r);  // konverterer til korrekt tal
            
            if (type.equals("grass")) {
                plantRandomGrass(world, amount, r);
            }
            
            if (type.equals("rabbit")) {
                plantRandomRabbits(world, amount, r);
            }
            
            if (type.equals("burrow")) {
                plantRandomBurrows(world, amount, r);
            }
        }

        p.show();
        p.run();
    }
    
    //hjælpe metode til at plante random grass i verdenen
    private static void plantRandomGrass(World world, int amount, Random rand) {
    int size = world.getSize();
    
    for (int i = 0; i < amount; i++) {
        Location l;
        do {
            l = new Location(rand.nextInt(size), rand.nextInt(size));
        } while (world.getTile(l) != null || world.containsNonBlocking(l));
        world.setTile(l, new Grass());
        }
    }
    
    //hjælpe metode til at plante random kaniner i verdenen
    private static void plantRandomRabbits(World world, int amount, Random rand) {
        int size = world.getSize();

        for (int i = 0; i < amount; i++) {
            
        Location l;
        do {
            l = new Location(rand.nextInt(size), rand.nextInt(size));
        } while (world.getTile(l) != null);
        world.setTile(l, new Rabbit());
        }
    }
    
    //hjælpe metode til at Plante random kaninhuller i verdenen
    private static void plantRandomBurrows(World world, int amount, Random rand) {
        int size = world.getSize();
        
        for (int i = 0; i < amount; i++) {
            
        Location l;
        do {
            l = new Location(rand.nextInt(size), rand.nextInt(size));
        } while (world.getTile(l) != null);
        world.setTile(l, new Burrow());
        }
    }
    
    //metode til at indlæse filer
    private static int parseAmount(String amountStr, Random rand) {

        // Hvis det er et interval: fx "20-30"
        if (amountStr.contains("-")) {
            String[] parts = amountStr.split("-");
            int min = Integer.parseInt(parts[0]);
            int max = Integer.parseInt(parts[1]);
            return min + rand.nextInt(max - min + 1);
        }

        // Hvis det er et enkelt tal: fx "3"
        return Integer.parseInt(amountStr);
    }
    
    }
