package itumulator.simulator;

import itumulator.world.World;
import itumulator.simulator.Actor;
import java.util.Random;
import itumulator.world.NonBlocking;

public class Burrow implements Actor, NonBlocking {
    private Random rand = new Random();
    
    @Override
    public void act(World world) {
        
    }
    
}