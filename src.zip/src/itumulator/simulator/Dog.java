package itumulator.simulator;

import itumulator.simulator.Actor;
import itumulator.world.World;
import itumulator.world.Location;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.Random;

public class Dog implements Actor {

    private Person owner;
    private Random random = new Random();

    public Dog(Person owner) {
        this.owner = owner;
    }

    @Override
    public void act(World world) {


        if (!world.contains(owner)) {
            world.delete(this);
            return;
        }


        if (!world.isOnTile(owner)) {
            return;
        }

  
        Location ownerLoc = world.getLocation(owner);


        Set<Location> empty = world.getEmptySurroundingTiles(ownerLoc);

        if (!empty.isEmpty()) {
            List<Location> list = new ArrayList<>(empty);
            int index = random.nextInt(list.size());
            Location moveTo = list.get(index);

            world.move(this, moveTo);
        }
    }
}
