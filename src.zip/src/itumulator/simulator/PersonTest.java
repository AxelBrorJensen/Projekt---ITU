package itumulator.simulator;
import itumulator.simulator.Actor;
import itumulator.world.World;
import itumulator.world.Location;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class PersonTest {
    World w;

    @BeforeEach
    public void setUp() {
        w = new World(2);
    }
    
    @Test
    public void personMovesDuringDay() {
        Person p = new Person(); 
        Location l = new Location(0,0);
        w.setDay(); 
        w.setCurrentLocation(l); 
        w.setTile(l, p); 
        
        p.act(w);
        
        
        Location n = w.getLocation(p); 
        assertNull(w.getTile(l)); 
        assertNotNull(n); 
        assertNotEquals(l, n); 
    }
    
    
    @Test
    public void personDoesNotMoveWhenNoEmptyTilesAvailable() {
        // Arrange
        w.setDay();
    
        Person p = new Person();
        Location center = new Location(1,1);
        w.setTile(center, p);
    
        // Fortæl world at 'center' er den nuværende aktør
        w.setCurrentLocation(center);
    
        // Fyld alle nabo-felter med andre personer
        for (Location loc : w.getSurroundingTiles(center)) {
            w.setTile(loc, new Person());
        }
    
        // Act
        p.act(w);
    
        // Assert: personen må IKKE have flyttet sig
        Location after = w.getLocation(p);
        assertEquals(center, after);
    }
    
    @Test
    public void dogsAreCreatedWithCorrectProbability() {
        World w = new World(3);
    
        Person p = new Person();
        Location start = new Location(1,1);
        w.setTile(start, p);
    
        int trials = 100;
        int dogCount = 0;
    
        for (int i = 0; i < trials; i++) {
            p.act(w);
    
            if (p.getDog() != null) {
                dogCount++;
                w.delete(p.getDog());
                p.setDog(null);
            }
        }
    
        assertTrue(dogCount > 0, "Person fik aldrig en hund – sandsynlighed for lav");
        assertTrue(dogCount < trials, "Person fik hund i alle forsøg – sandsynlighed for høj");
        assertTrue(dogCount > 5 && dogCount < 40,
            "Antallet hunde (" + dogCount + ") er uden for forventet interval");
    }
}